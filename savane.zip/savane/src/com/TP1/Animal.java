package com.TP1;
import java.util.Iterator;
import java.lang.Iterable;
import java.util.Collections;
import java.util.ArrayList;
import java.util.Random;
// Fichier:     Animal.java
// Création:
// Auteurs:     Sara Haddad et Vyncent Larose
//
// Ce code n'est pas protégé par un copyright.
//
// Historique:
// Créé pour le cours IFT1025 H22

// Classe Animal qui implemente ProiePredateur
public abstract class Animal implements ProiePredateur {

    private int age;
    private int AGEMAX;
    private int ageMature;
    private double masse;
    private boolean estProie;
    private boolean estPredateur;
    private boolean estVivant;
    private boolean estMature;
    private double facteurCroissance;

    // Methodes vides pour un Animal, completes dans les enfants.
    public void nourritureProies(Herbe herbe){}
    public void nourriturePredateurs(ArrayList<Animal> nourriture, int getNombreProiesChassables){}
    public int getNourriture(){return 0;}
    public void manger(){};

    // Naissance d'un animal, initialisation des attributs communs aux lions et aux antilopes.
    public void naitre(){
        estVivant = true;
        estMature = false;
        setAge(0);
        setMasse(10);
    }

    // Vieillissement d'un animal en y ajoutant un an et en multipliant sa masse par son facteur de croissance (different pour un lion
    // ou une antilope). Maturation et mort de l'animal lorsque l'age correspondant est atteint.
    public void vieillir(){
        this.setAge(this.getAge()+1);
        this.setMasse(this.getMasse()*getFacteurCroissance());
        if (this.getAge() >= this.getAgeMature()){
            this.estMature = true;
        }
        if (this.getAge() > this.getAgeMax()){
            this.mourir();
        }
    }

    public void mourir(){estVivant = false;}; // Mort de l'animal
    public boolean estVivant(){return estVivant;}; // Pour savoir si l'animal est en vie
    public boolean estMature(){return estMature;}; //Pour savoir si l'animal est mature
    public void setProie( boolean proie ){estProie = proie;}; // Setter pour indiquer que l'animal est une proie
    public boolean estProie(){return estProie;}; // Pour savoir si l'animal est une proie
    public void setPredateur(boolean predateur){estPredateur = predateur;}; // Setter pour indiquer que l'animal est un predateur
    public boolean estPredateur(){return estPredateur;}; // Pour savoir si l'animal est un predateur
    public void setMasse( double masse ){this.masse = masse;}; // Setter pour la masse de l'animal
    public double getMasse(){return masse;}; // Getter pour la masse de l'animal
    public void setAge( int age ){this.age = age;}; // Setter pour l'age de l'animal
    public int getAge(){return age;}; // Getter pour l'age de l'animal
    public void setAgeMax(int AGEMAX){this.AGEMAX = AGEMAX;}; // Setter pour l'age max de l'animal
    public int getAgeMax(){return AGEMAX;}; // Getter pour l'age max de l'animal
    public void setAgeMature(int ageMature){this.ageMature = ageMature;}; // Setter pour l'age de maturite de l'animal
    public int getAgeMature(){return ageMature;}; // Getter pour l'age de maturite de l'animal
    public void setFacteurCroissance(double facteurCroissance){this.facteurCroissance = facteurCroissance;}; // Setter pour le facteur de croissance de l'animal
    public double getFacteurCroissance(){return facteurCroissance;}; // Getter pour le facteur de croissance de l'animal
}