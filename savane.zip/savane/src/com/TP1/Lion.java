package com.TP1;

// Fichier:     Lion.java
// Création:
// Auteurs:     Sara Haddad et Vyncent Larose
//
// Ce code n'est pas protégé par un copyright.
//
// Historique:
// Créé pour le cours IFT1025 H22

import java.util.ArrayList;

// Classe Lion, enfant, de Animal.
public class Lion extends Animal {

    public final static int AGEMAX = 50;
    private final static int ageMature = 5;
    private ArrayList<Animal> nourriture;
    private int nombreProiesChassables;

    // Donne la liste des individus afin d'y trouver des antilopes pour nourrir le lion, ainsi que le nombre d'antilopes chassables.
    @Override
    public void nourriturePredateurs(ArrayList<Animal> nourriture, int nombreProiesChassables){
        this.nourriture = nourriture;
        this.nombreProiesChassables = nombreProiesChassables;
    }

    // Retourne le nombre de proies chassables apres qu'un lion en aille mange afin de respecter le 20% dans Population.chasser().
    @Override
    public int getNourriture(){
        return nombreProiesChassables;
    }

    // Le lion mange jusqu'a ce qu'il n'aille plus faim. S'il n'y a pas assez d'antilopes disponibles pour lui, il meurt.
    public void manger(){
        double total = 0;
        for (Animal b : nourriture) {
            if (nombreProiesChassables == 0) {
                break;
            }
            if (b.estProie() && b.estVivant()) {
                total += b.getMasse();
                b.mourir();
                nombreProiesChassables -= 1;
            }
            if (total >= this.getMasse()*2) {
                break;
            }
        }
        if (total < this.getMasse()*2) {
            this.mourir();}
    }

    // Constructeur de la classe Lion, naissance, et assignation des valeurs propres aux lions.
    public Lion (double facteurCroissance){
        naitre();
        setAgeMax(AGEMAX);
        setAgeMature(ageMature);
        setPredateur(true);
        setFacteurCroissance(facteurCroissance);
    }

    // L'animal accouche, creation d'un nouveau lion
    @Override
    public Animal accoucher(){
        Lion bebe = new Lion(getFacteurCroissance());
        return bebe;
    }
}
