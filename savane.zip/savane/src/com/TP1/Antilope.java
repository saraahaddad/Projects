package com.TP1;

// Fichier:     Antilope.java
// Création:
// Auteurs:     Sara Haddad et Vyncent Larose
//
// Ce code n'est pas protégé par un copyright.
//
// Historique:
// Créé pour le cours IFT1025 H22

// Classe Antilope, enfant de Animal.
public class Antilope extends Animal {

    public final static int AGEMAX = 15;
    private final static int ageMature = 2;
    private Herbe nourriture;

    // Determine l'herbe disponible pour l'antilope qui desire manger.
    @Override
    public void nourritureProies(Herbe nourriture){
        this.nourriture = nourriture;
    }

    // L'antilope mange s'il y a assez d'herbe pour satisfaire sa faim, autrement, elle meurt.
    @Override
    public void manger(){
        if (nourriture.getMasseAnnuelle() >= this.getMasse()*2){
            nourriture.setMasseAnnuelle(nourriture.getMasseAnnuelle()-this.getMasse()*2);
        }
        else{
            this.mourir();
        }
    }

    // Constructeur de la classe Antilope, naissance, et assignation des valeurs propres aux antilopes.
    public Antilope (double facteurCroissance){
        naitre();
        setAgeMax(AGEMAX);
        setAgeMature(ageMature);
        setProie(true);
        setFacteurCroissance(facteurCroissance);
    }

    // L'animal accouche, creation d'une nouvelle antilope.
    @Override
    public Animal accoucher(){
        Antilope bebe = new Antilope(getFacteurCroissance());
        return bebe;
    }
}
