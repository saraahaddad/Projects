package com.TP1;
import java.util.Iterator;
import java.lang.Iterable;
import java.util.Collections;
import java.util.ArrayList;
import java.util.Random;

// Fichier:     Population.java
// Création:
// Auteurs:     Sara Haddad et Vyncent Larose
//
// Ce code n'est pas protégé par un copyright.
//
// Historique:
// Créé pour le cours IFT1025 H22

// Defini une population composee d'herbe et d'animaux (proies: antilopes; predateurs: lions).
public class Population implements EcoSysteme, Iterable<Animal> {

    private Herbe herbe;
    private ArrayList<Animal> individus = new ArrayList<>();

    private int nombreProies;
    private int nombreProiesMatures;
    private double masseProies;

    private int nombrePredateurs;
    private int nombrePredateursMatures;
    private double massePredateurs;

    // Retourne l'arraylist individus
    public ArrayList<Animal> getIndividus() {
        return individus;
    }

    // Constructeur de Population. Ajout des proies et des predateurs dans individus.
    public Population(Herbe herbe, ArrayList<Animal> proies, ArrayList<Animal> predateurs) {
        this.herbe = herbe;
        individus.addAll(proies);
        individus.addAll(predateurs);
    }

    // Enleve les animaux morts de la liste individus
    public void clean() {
        ArrayList<Animal> morts = new ArrayList<>();
        for (Animal a : individus){
            if (!a.estVivant()){morts.add(a);}
        }
        individus.removeAll(morts);
    }

    // Fait vieillir l'herbe et tous les animaux d'un an
    public void vieillir() {
        herbe.vieillir();
        for (Animal a : individus) {
            a.vieillir();
        }
        clean();
    }

    // Fait manger chaque animal de la liste individus en ordre croissant apres les avoir melanges, selon leur faim et la disponibilite
    // des ressources
    public void chasser() {
        melanger();
        int nombreProiesChassables = getNombreProiesChassables();
        for (Animal a : individus) {
            if (a.estPredateur() && a.estVivant()) {
                a.nourriturePredateurs(individus, nombreProiesChassables);
                a.manger();
                nombreProiesChassables = a.getNourriture();
            }
            else if (a.estProie() && a.estVivant()) {
                a.nourritureProies(herbe);
                a.manger();
            }
        }
        clean();
    }

    // Melange de la liste individus
    public void melanger() {
        Collections.shuffle(this.individus, new Random(4));
    }

    // Iterateur pour la liste individus
    public Iterator<Animal> iterator() {
        Iterator<Animal> it = individus.iterator();
        return it;
    }

    // Getter pour le nombre de proies.
    public int getNombreProies() {
        nombreProies = 0;
        for (Animal a : individus) {
            if (a.estProie() && a.estVivant()) {
                nombreProies += 1;
            }
        }
        return nombreProies;
    }

    // Getter pour le nombre de predateurs.
    public int getNombrePredateurs() {
        nombrePredateurs = 0;
        for (Animal a : individus) {
            if (a.estPredateur() && a.estVivant()) {
                nombrePredateurs += 1;
            }
        }
        return nombrePredateurs;
    }

    // Getter pour le nombre de proies matures.
    public int getNombreProiesMatures() {
        nombreProiesMatures = 0;
        for ( Animal a : individus ) {
            if (a.estProie() && a.estVivant() && a.estMature()) {
                nombreProiesMatures += 1;
            }
        }
        return nombreProiesMatures;
    }

    // Getter pour le nombre de predateurs matures.
    public int getNombrePredateursMatures() {
        nombrePredateursMatures = 0;
        for ( Animal a : individus ) {
            if (a.estPredateur() && a.estVivant() && a.estMature()) {
                nombrePredateursMatures += 1;
            }
        }
        return nombrePredateursMatures;
    }

    // Getter pour le nombre de proies chassables.
    public int getNombreProiesChassables() {
        return (int)Math.floor(getNombreProies()*0.2);
    }

    // Getter pour la masse totale des proies.
    public double masseProies() {
        masseProies = 0;
        for ( Animal a : individus ) {
            if (a.estProie() && a.estVivant()){
                masseProies += a.getMasse();
            }
        }
        return masseProies;
    }

    // Getter pour la masse totale des predateurs.
    public double massePredateurs() {
        massePredateurs = 0;
        for ( Animal a : individus ) {
            if (!a.estProie() && a.estVivant()){
                massePredateurs += a.getMasse();
            }
        }
        return massePredateurs;
    }

    // Reproduction des animaux en parcourant la liste individus tout en respectant la limite d'accouchements des lions et des antilopes.
    public void reproduire() {
        int nbAccouchementsProies = (int)Math.floor(getNombreProiesMatures()/2);
        int nbAccouchementsPredateurs = (int)Math.floor(getNombrePredateursMatures()/2);
        for ( int i = 0; i < individus.size(); i++) {
            if (nbAccouchementsProies == 0 && nbAccouchementsPredateurs == 0){break;}
            if (individus.get(i).estVivant() && individus.get(i).estMature()){
                if (individus.get(i).estProie() && nbAccouchementsProies != 0){
                    individus.add(individus.get(i).accoucher());
                    nbAccouchementsProies -= 1;
                }
                if (individus.get(i).estPredateur() && nbAccouchementsPredateurs != 0){
                    individus.add(individus.get(i).accoucher());
                    nbAccouchementsPredateurs -= 1;
                }
            }
        }
    }
}