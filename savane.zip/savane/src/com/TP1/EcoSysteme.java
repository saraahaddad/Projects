package com.TP1;

public interface EcoSysteme {
    int getNombreProies();

    int getNombrePredateurs();

    int getNombreProiesMatures();

    int getNombrePredateursMatures();

    int getNombreProiesChassables();

    double masseProies();

    double massePredateurs();

    void vieillir();

    void chasser();

    void reproduire();

    void melanger();
}
