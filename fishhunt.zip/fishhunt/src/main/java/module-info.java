module com.example.fishhunt {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;

    opens com.example.fishhunt to javafx.fxml;
    exports com.sara.fishhunt;
}