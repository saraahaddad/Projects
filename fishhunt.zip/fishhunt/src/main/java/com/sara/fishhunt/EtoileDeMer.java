package com.sara.fishhunt;

public class EtoileDeMer extends Poisson {

    private final int amplitude = 50;       // amplitude d'oscillation
    private double phaseOrigine;            // position en Y initiale de l'etoile
    private double vitesseHorizontale;

    public EtoileDeMer(int level){
        this.vitesseHorizontale = super.vitesseHorizontale(level);  // generer vitesse horizontale
        this.phaseOrigine = calculerY(480);                   // generer Y initiale
        setPositionX();
    }

    // etoile peut apparaitre de la gauche ou de la droite
    public void setPositionX(){
        this.departGauche();
        if (!getDepartGauche()) {           // elle apparait a droite
            setX(640);
        }
        else {                              // elle apparait a gauche
            setX(-10);
        }
    }

    // mise a jour de la position en Y a chaque appel
    public void updateY(double dt) {
        double y = amplitude * Math.sin((2 * Math.PI) * dt * 1e-9) + phaseOrigine; // mouvement sinusoidal
        setY(y);
    }

    // mise a jour de la position en Y a chaque appel
    public void updateX(double dt){
        double newX = getDepartGauche() ? (getX() + vitesseHorizontale * dt) : (getX() - vitesseHorizontale * dt);
        setX(newX);
    }
}