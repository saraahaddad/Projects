package com.sara.fishhunt;

public class Balle {

    private double x, y;             // position de la balle
    private int vitesse;             // vitesse de diminution du rayon de la balle
    private double rayon;            // rayon actuel de la balle
    private double rayonPrecedent;   // rayon precedent de la balle

    public Balle(double rayon, double x, double y){
        this.rayon = rayon;
        this.x = x;
        this.y = y;
        this.vitesse = 300;
    }

    // la balle touche un poisson <-> les coordonnees de la balle sont dans l'intervalle de celles du poisson
    public boolean intersection(Poisson poisson){
        boolean dx1 = poisson.getX()+100 >= this.x;
        boolean dx2 = poisson.getX() <= this.x;
        boolean dy1 = poisson.getY()+100 >= this.y;
        boolean dy2 = poisson.getY() <= this.y;
        boolean intersects = (dx1 && dx2 && dy1 && dy2);
        return intersects;
    }

    // mettre a jour le rayon
    public void updateRayon(double rayon, double dt){
        rayonPrecedent = rayon;         // stocker le rayon precedent avant mise a jour
        rayon -= dt * getVitesse();     // diminuer le rayon apres chaque appel
        setRayon(rayon);
    }

    // getters et setters pour l'encapsulation
    public int getVitesse(){
        return vitesse;
    }

    public double getRayonPrecedent(){ return rayonPrecedent;}

    public void setRayon(double rayon){
        this.rayon = rayon;
    }

    public double getRayon(){
        return rayon;
    }
}