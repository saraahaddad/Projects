package com.sara.fishhunt;

import javafx.animation.AnimationTimer;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.image.Image;
import javafx.util.Duration;

public class Controleur {

    private FishHunt vue;                   // vue de l'architecture MVC
    private String[] poissonsSpeciaux;      // tableau pour stocker les 2 poissons speciaux
    private Bulle[][] bulles;               // tableau pour generer 3 groupes de 5 bulles
    private int level = 0;                  // initialiser niveau
    private int score = 0;                  // initialiser score
    private int vies ;                      // initialiser nombre de vies
    private PoissonNormal poissonN;         // poisson normal actuel
    private Poisson poissonS;               // poisson special actuel
    private boolean mancheEnCours;          // true tout au long d'une partie

    public Controleur(FishHunt vue){
        this.vue = vue;
        this.bulles = new Bulle[3][5];
        this.poissonsSpeciaux = new String[2];
        this.poissonsSpeciaux[0] = "file:Images/crabe.png";
        this.poissonsSpeciaux[1] = "file:Images/star.png";
    }

    public void commencerPartie(){
        vue.clearChildren();              // enlever les enfants de la racine a chaque debut de partie
        vies = 3;                         // on a initialement 3 vies
        level = 0;
        score = 0;
        mancheEnCours = true;
        vue.initialiserScore();           // affichage initial
        vue.poissonsRates();              // afficher les poissons qui representent les vies
        poissonsRates();
        vue.afficherCible();              // afficher la cible
        afficherNiveau();                 // afficher niveau courant
        commencerAnimation();             // commencer a afficher les poissons
    }

    // commencer la suite d'evenements: afficher un poisson chaque 3 secondes
    /*
         nous avons tente d'afficher les poissons speciaux a chaque 5 secondes mais ca ne fonctionne pas avec
         les keyframes
     */
    Timeline time = new Timeline(
            new KeyFrame(Duration.seconds(3), event -> {
                mancheEnCours = true;
                gestionAffichage();
            })
    );

    public void commencerAnimation(){
        time.setCycleCount(Timeline.INDEFINITE);
        time.play();
    }

    // sauvegarde le score a la fin d'une partie pour ecrire le nom et trier le fichier de scores
    public void addScore(String name){
        if(name != "") {
            Highscores.write(score, name);
            vue.retournerMenu();
        }
    }

    public int getScore(){
        return score;
    }

    public void gameOver(){
        mancheEnCours = false;      // la partie est terminee
        vue.gameOver();             // afficher message game over
        vue.afficherHighscores();   // mettre a jour les scores
        time.stop();                // arreter le time line
    }

    private boolean affichage = false;
    public void setAffichage(boolean affichage){this.affichage = affichage;}

    public void afficherNiveau(){
        level += 1;                           // on monte de niveau
        mancheEnCours = false;                // mettre en pause la partie pendant affichage
        if (affichage){vue.getTimeLine().stop();}
        vue.afficherNiveau(level);            // afficher niveau courant
        affichage = true;
        time.stop();
        commencerAnimation();                 // reprendre l'affichage
    }


    public void updateScore(){
        score+=1;                   // mettre a jour le score
        vue.afficherScore(score);
        if (score % 5 == 0){        // a chaque fois que le score est un multiple de 5
            afficherNiveau();       // on monte de niveau
        }
    }

    // ajouter une vie avec la touche K
    public void ajouterUneVie(){
        if(vies < 3){
            vies++;
            vue.retirerChances();
            poissonsRates();

        }
    }

    // generer le tableau de bulle: 3 groupes de 5 bulles, chaque groupe a une coordonnee de base en X
    public Bulle[][] genererBulles(){
        for(int groupes = 0; groupes < 3; groupes++) {
            double baseX = Math.random() * (vue.getWidth() - 1);
            double[] coordonneeEnX = new double[2];
            coordonneeEnX[0] = baseX + 20;
            coordonneeEnX[1] = baseX - 20;
            for (int i = 0; i < 5; i++) {
                this.bulles[groupes][i] = new Bulle(vue.getHeight());
                int index = (int) (Math.random());
                this.bulles[groupes][i].setCoordonneeX(coordonneeEnX[index]);
            }
        }
        return this.bulles;
    }

    double avancer = 0;       // preserver le temps pendant lequel le crabe avance
    double reculer = 0;       // preserver le temps pendant lequel le crabe recule
    double tempsEcouleS = 0;  // preserver le temps d'affichage des poissons speciaux pour afficher a chaque 5 secondes

    public void gestionAffichage(){
        // creer le poisson normal et generer sa position Y initiale
        PoissonNormal poisson = new PoissonNormal(level);
        Image imageNormal = new Image(poisson.getUrl());
        poissonN = poisson;
        poisson.calculerY(vue.getHeight());

        // creer le poisson special a afficher au moment adequat et generer sa position Y initiale
        String special = poissonsSpeciaux[(int) (Math.random() * 2)];  // 50/50 crabe et etoile
        Image imageSpecial = new Image(special);
        poissonS = (special == poissonsSpeciaux[0]) ? (new Crabe(level)) : (new EtoileDeMer(level));
        poissonS.calculerY(vue.getHeight());

        genererBulles();
        tempsEcouleS += 3;

        AnimationTimer timer = new AnimationTimer() {
            private long lastTime = 0;
            @Override
            public void handle(long now) {

                if (lastTime == 0) {
                    lastTime = now;
                    return;
                }

                double deltaTime = (now - lastTime) * 1e-9;
                // mettre a jour les coordonnees des bulles et faire l'affichage
                for (Bulle[] groupe: bulles) {
                    for (Bulle bulle : groupe) {
                        bulle.update(deltaTime);
                        vue.afficherBulles(bulle.getCoordonneeX(), bulle.getCoordonneeY(), bulle.getYPrecedent(), bulle.getRayon());
                    }
                }

                // afficher un poisson special chaque 5 secondes
                if ((int)tempsEcouleS % 5 == 0 && level >= 2 && mancheEnCours) {
                    if (poissonS instanceof Crabe && poissonS != null) {
                        if (poissonS.getX() > vue.getWidth() || poissonS.getX() < -100) {
                            this.stop();
                        }
                        ((Crabe)poissonS).update(deltaTime, avancer, reculer);
                        avancer += deltaTime;

                        // le crabe finit d'avancer = on commence a reculer
                        if (avancer > 0.5) {
                            reculer += deltaTime;
                        }
                        if (reculer > 0.25) {
                            reculer = 0;
                            avancer = 0;
                        }
                        // verifier avant d'afficher si on a cible le poisson
                        conditionsAffichage(imageSpecial, poissonS, this);
                    }
                    else if (poissonS instanceof EtoileDeMer && poissonS != null && mancheEnCours){
                        ((EtoileDeMer) poissonS).updateX(deltaTime);
                        ((EtoileDeMer) poissonS).updateY(now);
                        conditionsAffichage(imageSpecial, poissonS, this);
                    }
                }
                // le poisson depasse l'ecran
                if (poisson.getX() > vue.getWidth() || poisson.getX() < -100) {
                    this.stop();
                }
                poisson.updateX(deltaTime);
                poisson.updateY(deltaTime);
                conditionsAffichage(imageNormal, poissonN ,this);
                lastTime = now;
            }
        };
        timer.start();
    }

    public void poissonsRates() {
        if (vies > 0) {
            vue.afficherPoissonsRate1();
        }
        if (vies > 1) {
            vue.afficherPoissonsRate2();
        }
        if (vies > 2) {
            vue.afficherPoissonsRate3();
        }
    }

    // avant d'afficher: verifier qu'on a encore des vies, qu'on n'a pas cible le poisson, et qu'il n'a pas depasse
    // l'ecran
    public void conditionsAffichage(Image image, Poisson poisson, AnimationTimer timer){
        // retirer une vie si on ne cible pas le poisson et on n'est pas en transition de niveaux
        if (mancheEnCours && poisson != null && (poisson.getX() > vue.getWidth() || poisson.getX() < -100)) {
            vies -= 1;
            vue.retirerChances();
            poissonsRates();
            timer.stop();
        }

        // arreter la partie une fois qu'on perd
        if (vies == 0) {
            gameOver();
            timer.stop();
        }

        // afficher tant que le poisson n'est pas null
        if (poisson != null) {
            if(poisson.getDepartGauche()) {
                vue.afficherPoissons(image, poisson.getX(), poisson.getY(), poisson.getCouleur());
            }
            else{
                vue.afficherPoissons(ImageHelpers.flop(image), poisson.getX(), poisson.getY(), poisson.getCouleur());
            }
        }
    }

    // lancer une balle avec la cible, des qu'on clique quelque part sur l'ecran lors d'une partie
    public void lancerBalle(double x, double y){
        double rayon = 50;                                        // initialiser rayon de la balle
        Balle balle = new Balle(rayon, x, y);

        AnimationTimer timer = new AnimationTimer() {
            private long lastTime = 0;

            @Override
            public void handle(long now) {

                if (lastTime == 0) {
                    lastTime = now;
                    return;
                }

                // verifier l'intersection avec le poisson uniquement au cours d'une partie
                if (mancheEnCours && balle.getRayon() <= 0.1){
                    boolean intersects;
                    if (poissonN != null){
                        intersects = poissonN.intersection(balle, poissonN);
                        if (intersects){
                            vue.eliminerPoisson(poissonN.getX(), poissonN.getY());
                            poissonN = null;
                            updateScore();
                        }
                    }

                    if (poissonS != null){
                        intersects = poissonS.intersection(balle, poissonS);
                        if (intersects){
                            vue.eliminerPoisson(poissonS.getX(), poissonS.getY());
                            poissonS = null;
                            updateScore();
                        }
                    }
                    // reiinitialiser rayon
                    balle.setRayon(0);
                    vue.afficherBalle(x,y, balle.getRayon(), balle.getRayonPrecedent());
                    this.stop();
                }

                double deltaTime = (now - lastTime) * 1e-9;
                balle.updateRayon(balle.getRayon(), deltaTime);
                vue.afficherBalle(x,y, balle.getRayon(), balle.getRayonPrecedent());
                lastTime = now;
            }
        };
        timer.start();
    }
}