package com.sara.fishhunt;

import java.util.Objects;

public class PoissonNormal extends Poisson{

    private final int gravite = 100;     // acceleration en Y vers le bas
    private String[] poissonsNormaux;    // tableaux des poissons normaux
    private String url;                  // url du poisson cree
    private double vitesseHorizontale;
    private double vitesseVerticale;

    public PoissonNormal(int level){
        this.vitesseVerticale = super.getVitesseVerticale();
        this.vitesseHorizontale = super.vitesseHorizontale(level);
        setPositionX();
        remplirTableau();
        setUrl(choisirUrl());
    }

    // poisson peut apparaitre de la gauche ou de la droite
    public void setPositionX(){
        this.departGauche();
        if(!getDepartGauche()){
            setX(640);
        }
        else{setX(-100);}
    }

    // remplir le tableau des 8 poissons normaux possibles
    public void remplirTableau(){
        this.poissonsNormaux = new String[8];
        this.poissonsNormaux[0] = "file:Images/fish/00.png";
        this.poissonsNormaux[1] = "file:Images/fish/01.png";
        this.poissonsNormaux[2] = "file:Images/fish/02.png";
        this.poissonsNormaux[3] = "file:Images/fish/03.png";
        this.poissonsNormaux[4] = "file:Images/fish/04.png";
        this.poissonsNormaux[5] = "file:Images/fish/05.png";
        this.poissonsNormaux[6] = "file:Images/fish/06.png";
        this.poissonsNormaux[7] = "file:Images/fish/07.png";
    }

    // generer url aleatoire
    public String choisirUrl(){
        return(poissonsNormaux[(int) (Math.random() * 8)]);
    }

    public void setUrl(String url){
        this.url = url;
    }

    public String getUrl(){
        return url;
    }

    // mettre a jour la position en X
    public void updateX(double dt){
        double newVitesse = getVitesseHorizontale() * dt;
        double newX = getDepartGauche() ? (getX() + newVitesse) : (getX() - newVitesse);
        setX(newX);
    }

    // mettre a jour la position en Y
    public void updateY(double dt){
        vitesseVerticale += dt * gravite;
        setY(getY() + dt * vitesseVerticale);
    }

    // generer la vitesse horizontale
    public double getVitesseHorizontale(){
        return this.vitesseHorizontale;
    }
}