package com.sara.fishhunt;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

// Classe permettant la gestion de liste des meilleurs scores
public class Highscores {

    private static final ArrayList<String> names = new ArrayList<>();       // ArrayList des noms
    private static final ArrayList<Integer> scores = new ArrayList<>();     // ArrayList des scores
    public static ArrayList<Integer> getScores() {
        return scores;
    }
    public static ArrayList<String> getNames() {
        return names;
    }

    // Lecture et arrangement du fichier HighscoresList qui contient les 10 meilleurs scores
    public static void read(){

        try {
            names.clear();
            scores.clear();
            Scanner scan = new Scanner(new FileInputStream("HighscoresList"));

            while (scan.hasNext()) {
                int score = scan.nextInt();
                String name = scan.nextLine().substring(1);

                boolean entre = false;      // Verifie si le score a deja ete place dans la liste
                if (scores.isEmpty()) {     // Le premier score lu est mis a l'index 0
                    scores.add(score);
                    names.add(name);
                    entre = true;
                }

                for(int i = 0; i < scores.size(); i++){     // Verifie chaque nouveau score afin de le placer au bon
                    if(score > scores.get(i)) {             // endroit (le plus haut est en position 1), un score egal a
                        scores.add(i, score);               // un autre sera place juste en dessous
                        names.add(i, name);                 // Une fois le score entre, on place le nom correspondant au
                        entre = true;                       // au meme niveau
                        break;
                    }
                }
                if (!entre){            // Si le score est inferieur a tous ceux deja dans le tableau, on le met a la
                    scores.add(score);  // fin de ce dernier
                    names.add(name);
                }
            }
            keep(10);   // On ne garde que les 10 meilleurs scores
            rewrite();

        } catch (IOException ex) {
            System.out.println("Erreur ouverture fichier.");
        }
    }

    // Reecriture du document HighscoresList, chaque ligne est composee du score, un espace, et le nom
    public static void rewrite(){
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter("HighscoresList"));
            String texte = "";
            for (int i = 0; i < scores.size(); i++){
                texte += scores.get(i) + " " + names.get(i);
                writer.append(texte);
                if(i != scores.size()-1){writer.newLine();}
                texte = "";
            }
            writer.close();
        }
        catch (IOException ex){
            System.out.println("Erreur ouverture fichier.");
        }
    }

    // Ajout d'un nouveau score
    public static void write(int nouveauScore, String nouveauNom){
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter("HighscoresList", true));
            if(!scores.isEmpty()){
                writer.newLine();
            }
            writer.append(nouveauScore + " " + nouveauNom);
            writer.close();
        }

        catch (IOException ex) {
            System.out.println("Erreur ouverture fichier.");
        }
    }

    // Conserve seulement un certain nombre de lignes, max = 10 est ce qui nous interesse
    public static void keep(int max){
        while(scores.size() > max) {
            scores.remove(max);
            names.remove(max);
        }
    }
}