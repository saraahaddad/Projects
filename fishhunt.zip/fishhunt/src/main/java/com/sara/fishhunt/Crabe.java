package com.sara.fishhunt;

public class Crabe extends Poisson {

    private double vitesseHorizontale;

    public Crabe(int level){
        this.vitesseHorizontale = 1.3 * super.vitesseHorizontale(level);
        setY(calculerY(480));
        setPositionX();
    }

    // crabe peut apparaitre de la gauche ou de la droite
    public void setPositionX(){
        this.departGauche();

        if (!getDepartGauche()) {       // crabe apparait a droite
            setX(640);
        }
        else {                          // crabe apparait a gauche
            setX(-10);
        }
    }

    public void update(double dt, double avancer, double reculer){
        // le crabe avance en oscillant: avancer pendant 0.5s puis reculer pendant 0.25s
        // mouvement contraire si le crabe commence a droite
        if (avancer < 0.5) {
            double newX = getDepartGauche() ? (getX() + dt * vitesseHorizontale) : (getX() - dt * vitesseHorizontale);
            setX(newX);
        }
        else if (reculer < 0.25) {
            double newX = getDepartGauche() ? (getX() - dt * vitesseHorizontale) : (getX() + dt * vitesseHorizontale);
            setX(newX);
        }
    }

}