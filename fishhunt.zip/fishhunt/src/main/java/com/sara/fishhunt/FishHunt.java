package com.sara.fishhunt;
// Date de remise: 29/04/2022
// Auteurs: Sara Haddad et Vyncent Larose

// Ce programme simule le jeu de "Fish Hunt", avec la librairie JavaFx

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.util.*;

public class FishHunt extends Application{

    private Controleur controleur = new Controleur(this);     // colle entre vue et modele
    private GraphicsContext context;                              // permet de dessiner des formes
    private int width = 640;                         // largeur de la fenetre
    private int height = 480;                        // hauteur de la fenetre
    private Pane rootStart;                          // racine de la scene de jeu
    private VBox rootScores;                         // racine de la scene de score
    private Stage stage;                             // permet de changer de scene
    private Scene highscores;                        // fenetre des highscores
    private Scene nouvellePartie;                    // fenetre du jeu
    private HBox hBox;                               // permet d'entrer le score apres une partie
    private Scene splashScreenScene;                 // afficher le logo au debut du jeu
    private Text nombrePoints = new Text();          // sauvegarde les nombres de points apres une partie
    ListView<String> list;                           // liste des meilleurs scores
    String urlRate = "file:Images/fish/00.png";      // url de l'image des poissons rates

    public static void main(String[] args){
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        stage = primaryStage;

        sceneAccueil();                              // creer la scene d'accueil
        sceneNouvellePartie();                       // creer la scene de jeu
        sceneHisghscores();                          // creer la sene des meilleurs scores
        updateHighscores();                          // permettre d'entrer le nom du joueur apres chaque partie

        primaryStage.setScene(splashScreenScene);    // au depart la scene est celle du logo de jeu
        primaryStage.setTitle("Fish Hunt");          // titre de la fenetre
        primaryStage.setResizable(false);
        primaryStage.show();

        // debogguage -> appeler la fonction adequate dans le controleur
        nouvellePartie.setOnKeyPressed(event ->{
            switch(event.getCode()){
                case H:
                    controleur.afficherNiveau();
                    break;
                case J:
                    controleur.updateScore();
                    break;
                case K:
                    controleur.ajouterUneVie();
                    break;
                case L:
                    controleur.gameOver();
                    break;
            }
        });
    }

    private void updateHighscores() {
        Text votreNom = new Text("Votre nom: ");    // pour entrer le score apres une partie
        TextArea textArea = new TextArea();
        textArea.setMaxHeight(10);
        textArea.setMaxWidth(250);

        Button ajouter = new Button("Ajouter!");    // ajouter le score
        ajouter.setPadding(new Insets(10));
        Button menu = new Button("Menu");           // revenir au menu principal
        menu.setPadding(new Insets(10));

        hBox = new HBox();
        hBox.setAlignment(Pos.CENTER);
        hBox.getChildren().addAll(votreNom,textArea,nombrePoints,ajouter);

        rootScores.getChildren().add(list);
        rootScores.getChildren().add(menu);

        // trier la liste et ajouter le score actuel si parmis les 10 meilleurs
        ajouter.setOnMouseClicked((event)->{
            Highscores.read();
            controleur.addScore(textArea.getText());
        });

        // retour au menu principal
        menu.setOnMouseClicked((event)->{
            retournerMenu();
        });
    }

    private void sceneHisghscores() {
        // scene des highscores
        rootScores = new VBox();
        highscores = new Scene(rootScores, width, height);
        Text meilleursScores = new Text("Meilleurs scores");
        meilleursScores.setFont(Font.font("Times New Roman",36));
        rootScores.setAlignment(Pos.TOP_CENTER);
        rootScores.setPadding(new Insets(10));
        rootScores.setSpacing(10);
        list = new ListView<>();
        list.setMaxHeight(242);
        list.setMaxWidth(400);
        rootScores.getChildren().add(meilleursScores);
    }

    private void sceneAccueil() {
        // scene principale, qui affiche le logo
        VBox splashScreenRoot = new VBox();
        splashScreenRoot.setBackground((new Background(new BackgroundFill(
                Color.rgb(0,0,139), CornerRadii.EMPTY, Insets.EMPTY))));
        splashScreenScene = new Scene(splashScreenRoot, width, height);
        VBox accueil = new VBox();
        Image splashImg = new Image("file:Images/logo.png");
        ImageView view = new ImageView(splashImg);
        accueil.getChildren().add(view);
        Button start = new Button("Nouvelle Partie!");
        Button scores = new Button("Meilleurs Scores");
        accueil.setAlignment(Pos.CENTER);
        accueil.setSpacing(5);
        accueil.getChildren().addAll(start, scores);
        splashScreenRoot.getChildren().add(accueil);
        stage.getIcons().add(splashImg);

        // afficher menu des highscores
        scores.setOnMouseClicked((event)->{
            stage.setScene(highscores);
            afficherHighscoresMenu();
        });

        // afficher scene de debut de partie
        start.setOnMouseClicked((event)->{
            stage.setScene(nouvellePartie);
            controleur.commencerPartie();
        });
    }

    private void sceneNouvellePartie() {
        // scene qui contient le canavs de jeu au debut d'une nouvelle partie
        rootStart = new Pane();
        nouvellePartie = new Scene(rootStart, width, height);
        Canvas canvas = new Canvas(width, height);
        context = canvas.getGraphicsContext2D();
        rootStart.getChildren().add(canvas);
        rootStart.setBackground((new Background(new BackgroundFill(
                Color.rgb(0,0,139), CornerRadii.EMPTY, Insets.EMPTY))));
    }

    // retourne la hauteur de la fenetre
    public int getHeight(){
        return this.height;
    }

    // retourne la largeur de la fenetre
    public int getWidth(){
        return this.width;
    }

    VBox scoreBox = new VBox();
    Text scoreText = new Text();

    // premier appel d'une nouvelle partie, ajouter les enfants a la scene et initialiser au niveau 1
    public void initialiserScore(){
        scoreBox.setTranslateX(310);
        scoreText.setFont(Font.font("Arial", 40));
        scoreText.setFill(Color.WHITE);
        scoreText.setText("0");
        scoreBox.getChildren().add(scoreText);
        rootStart.getChildren().add(scoreBox);
    }

    // nouvelle partie -> tout reinitialiser
    public void clearChildren(){
        rootStart.getChildren().removeAll(rootStart.getChildren());
        scoreBox.getChildren().removeAll(scoreBox.getChildren());
        Canvas canvas = new Canvas(width, height);
        context = canvas.getGraphicsContext2D();
        rootStart.getChildren().add(0,canvas);
    }

    // revenir au menu principal apres avoir ajoute les scores
    public void retournerMenu(){
        stage.setScene(splashScreenScene);
        list.getItems().clear();
        rootScores.getChildren().remove(hBox);
    }

    // lire et trier la liste des scores pour garder les 10 meilleurs
    public void afficherHighscores(){
        Highscores.read();
        ArrayList<Integer> scores = Highscores.getScores();
        ArrayList<String> names = Highscores.getNames();
        rootScores.getChildren().add(2, hBox);
        nombrePoints.setText(" a fait " + controleur.getScore() + " points! ");
        if (scores.size() > 0) {
            for (int i = 0; i < scores.size(); i++) {
                list.getItems().add((i + 1) + ".\t" + scores.get(i) + "   " + names.get(i));
            }
        }
    }

    // affichage des 10 meilleurs scores
    public void afficherHighscoresMenu() {
        Highscores.read();
        ArrayList<Integer> scores = Highscores.getScores();
        ArrayList<String> names = Highscores.getNames();
        for(int i = 0; i < scores.size(); i++) {
            list.getItems().add((i+1) + ".\t" + scores.get(i) + "   " + names.get(i));
        }
    }

    // permet de redessiner le poisson apres chaque appel
    public void eliminerPoisson(double positionEnX, double positionEnY){
        context.clearRect(positionEnX-25 , positionEnY-25 , 150, 150);
    }

    // dessiner l'image du poisson correspondant a chaque appel
    public void afficherPoissons(Image image, double positionEnX, double positionEnY, Color couleur){
        context.clearRect(positionEnX - 25 , positionEnY - 25 , 150, 150);
        context.drawImage(ImageHelpers.colorize(image,couleur),positionEnX,positionEnY,100,100);
    }

    // desssine une bulle a chaque appel, avec une position et rayons specifiques
    public void afficherBulles(double positionEnX, double positionEnY, double yPrecedent, double rayon){
        context.setFill(Color.rgb(0,0,139));
        context.fillOval(positionEnX-1,yPrecedent-1,rayon+2,rayon+2);
        context.setFill(Color.rgb(0,0,255,0.4));
        context.fillOval(positionEnX, positionEnY, rayon, rayon);
    }

    // affiche le niveau actuel de jeu
    private Text levelX;
    private Timeline timeLine;
    public Timeline getTimeLine(){return timeLine;};

    public void afficherNiveau(int level) {
        rootStart.getChildren().remove(levelX);
        levelX = new Text();
        levelX.setX(200); levelX.setY(240);
        levelX.setFill(Color.WHITE);
        levelX.setFont(Font.font("Arial", 80));
        levelX.setText("Level " + level);
        rootStart.getChildren().add(levelX);
        timeLine = new Timeline();
        KeyFrame keyFrame = new KeyFrame(Duration.seconds(3),event -> {
            rootStart.getChildren().remove(levelX);
            controleur.setAffichage(false);
        });
        timeLine.getKeyFrames().add(keyFrame);
        timeLine.playFromStart();
    }

    // afficher le message "game over" apres avoir perdu une partie
    public void gameOver(){
        Text gameOver = new Text();
        gameOver.setX(120);
        gameOver.setY(250);
        rootStart.getChildren().remove(levelX);
        rootStart.getChildren().add(gameOver);
        gameOver.setFill(Color.RED);
        gameOver.setFont(Font.font("Arial", 80));
        gameOver.setText("Game Over");

        Timeline time = new Timeline();
        time.setCycleCount(1);
        KeyFrame keyFrame = new KeyFrame(Duration.seconds(3),event -> {
            rootStart.getChildren().remove(gameOver);
        });

        time.getKeyFrames().add(keyFrame);
        time.playFromStart();
        time.setOnFinished((event) -> stage.setScene(highscores));
    }

    // afficher le score correspondant
    public void afficherScore(int score){
        scoreText.setText(String.valueOf(score));
    }

    // afficher les 3 vies en dessous du score
    private ImageView chance1View;
    private ImageView chance2View;
    private ImageView chance3View;
    public void poissonsRates(){
        Image chance1 = new Image(urlRate, 40, 40, false, true);
        chance1View = new ImageView(chance1);
        chance1View.setX(250);
        chance1View.setY(50);
        Image chance2 = new Image(urlRate, 40, 40, false, true);
        chance2View = new ImageView(chance2);
        chance2View.setX(300);
        chance2View.setY(50);
        Image chance3 = new Image(urlRate,40,40,false,true);
        chance3View = new ImageView(chance3);
        chance3View.setX(350);
        chance3View.setY(50);
    }

    public void afficherPoissonsRate1() {
        rootStart.getChildren().add(chance1View);
    }
    public void afficherPoissonsRate2() {
        rootStart.getChildren().add(chance2View);
    }
    public void afficherPoissonsRate3(){
        rootStart.getChildren().add(chance3View);
    }

    // retirer une vie lorsqu'on ne cible pas un poisson
    public void retirerChances(){
        rootStart.getChildren().remove(chance1View);
        rootStart.getChildren().remove(chance2View);
        rootStart.getChildren().remove(chance3View);
    }

    // afficher la cible au debut du jeu
    public void afficherCible(){
        Image img = new Image("file:Images/cible.png",50,50,false,true);
        ImageView imgView = new ImageView(img);
        imgView.setX(295);
        imgView.setY(265);
        rootStart.getChildren().add(imgView);

        rootStart.setOnMouseMoved((event) -> {
            imgView.setX(event.getX() - 25);
            imgView.setY(event.getY() - 25);
        });

        rootStart.setOnMouseClicked((event) -> {
            controleur.lancerBalle(event.getX(), event.getY());
        });
    }

    // re dessiner la balle a chaque appel avec un rayon plus petit, apres avoir efface la balle precedente
    public void afficherBalle(double x, double y, double rayon, double rayonPrecedent){
        context.setFill(Color.rgb(0,0,139));
        context.fillOval(x-rayonPrecedent-5,y-rayonPrecedent-5,2*rayonPrecedent+10,2*rayonPrecedent+10);
        context.setFill(Color.BLACK);
        context.fillOval(x - rayon,y - rayon,2*rayon,2*rayon);
    }

}
