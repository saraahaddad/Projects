package com.sara.fishhunt;
import javafx.scene.paint.Color;

import java.util.Objects;
import java.util.Random;

public class Poisson {

    private double vitesseHorizontale;
    private double vitesseVerticale = - (100 + Math.random()*(200 - 101)); // vitesse aleatoire entre 100 et 200px
    private boolean departGauche;                 // poisson peut commencer a gauche ou a droite
    private double x = 0;
    private double y = 0;
    private Color couleur = choisirCouleur();     // poisson a une couleur aleatoire

    // getters et setters pour l'encapsulation
    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }

    public double getX(){
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getVitesseVerticale(){
        return vitesseVerticale;
    }

    public Color getCouleur(){
        return this.couleur;
    }

    public boolean getDepartGauche(){
        return departGauche;
    }

    // calculer la vitesse horizontale du poisson
    public double vitesseHorizontale(int level){
        vitesseHorizontale = 100 * Math.pow(level, (double)1/3) + 200;
        return vitesseHorizontale;
    }

    // generer Y initiale du poisson entre 1/5 et 4/5 de la hauteur de l'ecran
    public double calculerY(int height){
        double borneMinimale = height / 5;
        double borneMaximale = (4 * height) / 5;
        y = borneMinimale + Math.random()*(borneMaximale - borneMinimale + 1);
        return y;
    }

    // probabilite de 50% pour la gauche et la droite
    public boolean departGauche(){
        double random = Math.floor(Math.random()*2);
        boolean gauche = Objects.equals(random, 0.0);
        departGauche = gauche;
        if(!gauche){this.setX(640);}
        return gauche;
    }

    // choisir une couleur aleatoire a attribuer au poisson
    public Color choisirCouleur(){
        Random random = new Random();
        int red = random.nextInt(256);
        int green = random.nextInt(256);
        int blue = random.nextInt(256);
        Color randomColor = Color.rgb(red,green,blue);
        return randomColor;
    }

    // verifie si le poisson a ete cible par la balle
    public boolean intersection(Balle balle, Poisson poisson) {
        boolean intersects = balle.intersection(poisson);
        return intersects;
    }
}

