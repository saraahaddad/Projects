package com.sara.fishhunt;

public class Bulle {

    private double rayon;            // rayon de la bulle
    private double vitesse;          // vitesse vers le haut
    private double coordonneeX;      // coordonnee de base en X
    private double coordonneeY;      // coordonnee actuelle en Y
    private double yPrecedent;       // coordonnee precedente en Y

    public Bulle(int height) {
        rayon = 10 + Math.random() * (40 - 11) ;      // rayon aleatoire entre 10 et 40px
        vitesse = 350 + Math.random() * (450 - 351);  // vitesse aleatoire entre 350 et 450 px/s
        coordonneeY = height - 10;
    }

    // getters et setters pour encapsulation
    public void setCoordonneeX(double coordonneeX){
        this.coordonneeX = coordonneeX;
    }

    public double getCoordonneeX(){
        return this.coordonneeX;
    }

    public double getCoordonneeY(){
        return this.coordonneeY;
    }

    public double getYPrecedent(){return this.yPrecedent;};

    public double getRayon(){
        return this.rayon;
    }

    // mise a jour des coordonnees
    public double update(double dt){
        vitesse += dt;
        yPrecedent = coordonneeY;                    // y precedente = y
        coordonneeY = yPrecedent - dt*vitesse;       // bulles montent vers le haut
        return coordonneeY;
    }
}